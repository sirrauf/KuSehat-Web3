from flask import Blueprint, request, current_app, jsonify
from werkzeug.utils import secure_filename
from luno_python.client import Client
import base64
import uuid
import os

endpoint_api_bp = Blueprint('endpoint_api', __name__, url_prefix='/api')
endpoint_api_bp.csrf_exempt = True

@endpoint_api_bp.route('/topup', methods=['GET'])
def tambah_saldo():
    if request.method == "GET":
        user = int(request.args.get('user_id'))
        metode = str(request.args.get("metode"))
        
        try:
            jumlah = float(request.args.get("jumlah", 0))
            if jumlah <= 0:
                return jsonify({"success": False, "error": "Jumlah harus lebih dari 0"})
            
        except (ValueError, TypeError):
            return jsonify({"success": False, "error": "Jumlah harus angka yang valid"})
        
        if not user or not metode:
            return jsonify({"success": False, "error": "User ID dan metode harus diisi"})
        
        try:
            result = current_app.Topup.tambah_saldo(user, jumlah, metode)
            
            if result:
                return jsonify({"status_code":200,"status": "Success"})
        except Exception as e:
            return jsonify({"success": False, "error": "Gagal melakukan topup"})
        
    return jsonify({"success": False, "error": "Method tidak didukung"})

@endpoint_api_bp.route('/exchange', methods=['GET', 'POST'])
def exchange():
    try:
        user_id = request.args.get('user_id')
        if not user_id:
            return jsonify({"success": False, "message": "User ID tidak ditemukan"}), 400
        
        user = current_app.db.get_user_by_id(int(user_id))
        if not user:
            return jsonify({"success": False, "message": "User tidak ditemukan"}), 404

        tujuan_rekening = request.args.get("tujuan")
        if not tujuan_rekening:
            return jsonify({"success": False, "message": "Tujuan rekening diperlukan"}), 400

        image_b64 = request.args.get('image_base64')
        if not image_b64:
            return jsonify({"success": False, "message": "Gambar base64 diperlukan"}), 400
        
        try:
            image_data = base64.b64decode(image_b64)
        except Exception as e:
            return jsonify({"success": False, "message": "Format base64 tidak valid"}), 400

        if not current_app.config.get('UPLOAD_FOLDER'):
            return jsonify({"success": False, "message": "Konfigurasi folder upload tidak ditemukan"}), 500

        filename = f"exchange_{uuid.uuid4().hex}_{secure_filename(str(tujuan_rekening))}.png"
        image_path = os.path.join(current_app.config['UPLOAD_FOLDER'], filename)
        
        # Buat folder jika belum ada
        os.makedirs(os.path.dirname(image_path), exist_ok=True)
        
        with open(image_path, "wb") as f:
            f.write(image_data)

        reward = current_app.Exchange.get_exchange_reward(str(tujuan_rekening))
        
        user.Saldo += reward

        current_app.db.session.commit() 

        return jsonify({
            "success": True, 
            "message": "Exchange berhasil", 
            "reward": reward,
            "saldo_baru": user.Saldo
        }), 200
        
    except ValueError:
        return jsonify({"success": False, "message": "User ID harus berupa angka"}), 400
    except Exception as e:
        current_app.logger.error(f"Error dalam proses exchange: {str(e)}")
        return jsonify({"success": False, "message": "Terjadi kesalahan internal"}), 500