from flask import Blueprint, render_template, request, session, redirect, url_for, current_app

auth_bp = Blueprint('auth', __name__, url_prefix='/auth')

@auth_bp.route("/login", methods=["GET","POST"])
def login():
    message = ''
    if request.method == 'POST' and 'email' in request.form and 'password' in request.form:
        email = request.form['email']
        password = request.form['password']
        
        user = current_app.auth.login(email, password)
        
        if user:
            session['loggedin'] = True
            session['userid'] = user['userid']
            session['name'] = user['namauser']
            session['email'] = user['email']
            
            message = 'Login berhasil!'
            return redirect(url_for('user.overview'))
        else:
            message = 'Email/Password Salah!'
        
    title = "Login | KuSehat"
    return render_template(
        "authentication/login.html",
        title=title,
        message=message
    )

@auth_bp.route("/register", methods=["GET","POST"])
def register():
    if request.method == "POST":
        full_name = request.form['full-name']
        email = request.form['email']
        password = request.form['password']
        confirm_password = request.form['confirm-password']
        
        add_user = current_app.auth.register(full_name,email,password)
        
        if add_user:
            message = 'Login berhasil!'
            return redirect(url_for('auth.login'))
        else:
            message = 'Gagal Untuk Register, Cek Data Anda!'
        
    title = "Register | KuSehat"
    return render_template(
        "authentication/register.html",
        title=title,
    )

@auth_bp.route('/logout')
def logout():
    session.pop('loggedin', None)
    session.pop('email', None)
    return redirect(url_for('index.index'))