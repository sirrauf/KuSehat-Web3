from flask import Blueprint, render_template

index_bp = Blueprint('index', __name__)

@index_bp.route("/", methods=["GET","POST"])
def index():
    title = "Api Documentation | KuSehat"
    return render_template(
        "index.html",
        title=title,
    )

@index_bp.route("/overview", methods=["GET","POST"])
def overview():
    title = "Overview | KuSehat"
    return render_template(
        "overview.html",
        title=title
    )