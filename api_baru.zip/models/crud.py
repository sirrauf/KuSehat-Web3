
class crud:
    def __init__(self, conn):
        self.connection = conn
        self.cursor = self.connection.cursor(dictionary=True)

    def query(self, sql_query, params=None, action='simpan'):
        try:
            self.cursor.execute(sql_query, params or ())

            if action.lower() == "read":
                return self.cursor.fetchall()
            elif action.lower() == "create":
                self.connection.commit()
                return self.cursor.lastrowid 
            elif action.lower() == "update":
                self.connection.commit()
                return self.cursor.rowcount
            elif action.lower() == "login":
                return self.cursor.fetchone()
            elif action.lower() == "simpan":
                self.connection.commit()
                return self.cursor.rowcount
        except Exception as e:
            self.connection.rollback()
            raise e