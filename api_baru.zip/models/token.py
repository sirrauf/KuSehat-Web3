import os
import jwt
from .crud import crud
from datetime import datetime
from dotenv import load_dotenv

load_dotenv()

class token():
    def __init__(self,conn):
        self.CRUD = crud(conn)
        self.waktu_sekarang = datetime.now()
        
    def create_token(self,user_id: int):
        payload = {
            'iat': self.waktu_sekarang,
            'id': user_id,
        }
        
        token = jwt.encode(
            payload,
            os.getenv('SECRET_KEY'),
            algorithm='HS256'
        )
        
        return token
    
    def save_token(self, userid: int, nama_user: str, new_token: str, old_token: str):
        try:
            print(old_token)
            if old_token:
                #! Update token existing
                query = "UPDATE token SET token = %s, created_at = NOW() WHERE userid = %s"
                params = (str(new_token), userid)
            else:
                #! Insert token baru
                query = """INSERT INTO token 
                        (userid, Nama_Pemilik, token, created_at) 
                        VALUES (%s, %s, %s, NOW())"""
                params = (userid, nama_user, str(token))
            
            return self.CRUD.query(query, params, 'simpan')
            
        except Exception as e:
            print(f"Error saat menyimpan token: {str(e)}")
            return False
    
    def get_token(self, user_id: int):
        query = 'SELECT token FROM token WHERE userid = %s'
        return self.CRUD.query(query, (user_id,), 'read')