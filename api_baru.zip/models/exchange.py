from .crud import crud

class exchange():
    def __init__(self,conn) -> None:
        self.CRUD = crud(conn)
    
    def get_exchange_reward(self, tujuan:str):
        tujuan = tujuan.lower()
        if tujuan == "dokter": return 100_000
        if tujuan == "data_ai": return 200_000
        return 0
    
    def simpan_result_exchange(self, user_id : int, file : str,tujuan_rek : str,):
        query = """INSERT INTO token 
                        (userid, Nama_Pemilik, token, created_at) 
                        VALUES (%s, %s, %s, NOW())"""
        params = (int(user_id), str(file), str(tujuan_rek))
        
        return self.CRUD.query(query, params, 'simpan')