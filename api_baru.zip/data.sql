-- Drop table if exists (using backticks consistently)
DROP TABLE IF EXISTS `user`;

-- Create user table with optimized structure
CREATE TABLE IF NOT EXISTS `user` (
  `userid` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `namauser` VARCHAR(100) NOT NULL,  -- Reduced length from 255
  `email` VARCHAR(100) NOT NULL,     -- Reduced length from 255
  `password` CHAR(60) NOT NULL,      -- Fixed length for bcrypt hashes
  `register_date` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `login_date` TIMESTAMP NULL DEFAULT NULL,
  `saldo` DECIMAL(15,2) NOT NULL DEFAULT 0.00,  -- Better for financial values
  PRIMARY KEY (`userid`),
  UNIQUE KEY `idx_email` (`email`),  -- Explicit index naming
  KEY `idx_login_date` (`login_date`)  -- Added index for login queries
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;

-- Insert with proper timestamp format
INSERT INTO `user` (`namauser`, `email`, `password`, `saldo`) 
VALUES ('Agus Sutrisno', 'sutris@gmail.com', 'pass123?', 111111.00);

-- Create token table with optimized structure
CREATE TABLE IF NOT EXISTS `token` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `userid` INT UNSIGNED NOT NULL,  -- Added reference to user table
  `Nama_Pemilik` VARCHAR(100),     -- Reduced length from 160
  `token` VARCHAR(255) NOT NULL,   -- Changed from TEXT to VARCHAR
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_token` (`token`),  -- Explicit index naming
  KEY `idx_userid` (`userid`),      -- Added index for joins
  CONSTRAINT `fk_token_user` FOREIGN KEY (`userid`) REFERENCES `user` (`userid`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;


CREATE TABLE IF NOT EXISTS `saldo` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT UNSIGNED NOT NULL,
  `metode_pembayaran` VARCHAR(100) NOT NULL,
  `jumlah` DECIMAL(20, 8) UNSIGNED NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_user` (`user_id`),
  CONSTRAINT `fk_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`userid`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS 'exchange_history'(
  'id'INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT UNSIGNED NOT NULL,

)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;