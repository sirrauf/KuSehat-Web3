 document.addEventListener('DOMContentLoaded', function () {
        const copyButton = document.getElementById('copy-button');
        const clipboardDefault = copyButton.querySelector('.clipboard-default');
        const clipboardSuccess = copyButton.querySelector('.clipboard-success');

        // Inisialisasi clipboard dengan callback manual
        copyButton.addEventListener('click', function () {
            const tokenText = document.getElementById('token-text').textContent;

            // Menggunakan Clipboard API modern
            navigator.clipboard.writeText(tokenText).then(function () {
                // Berhasil copy
                clipboardDefault.classList.add('hidden');
                clipboardSuccess.classList.remove('hidden');

                setTimeout(function () {
                    clipboardDefault.classList.remove('hidden');
                    clipboardSuccess.classList.add('hidden');
                }, 2000);
            }).catch(function (err) {
                console.error('Gagal menyalin menggunakan Clipboard API:', err);

                // Fallback menggunakan textarea
                const textarea = document.createElement('textarea');
                textarea.value = tokenText;
                textarea.style.position = 'fixed';
                document.body.appendChild(textarea);
                textarea.select();

                try {
                    const successful = document.execCommand('copy');
                    if (successful) {
                        clipboardDefault.classList.add('hidden');
                        clipboardSuccess.classList.remove('hidden');

                        setTimeout(function () {
                            clipboardDefault.classList.remove('hidden');
                            clipboardSuccess.classList.add('hidden');
                        }, 2000);
                    } else {
                        console.error('Gagal menyalin menggunakan execCommand');
                    }
                } catch (err) {
                    console.error('Gagal menyalin:', err);
                }

                document.body.removeChild(textarea);
            });
        });
    });