from .crud import crud

class exchange():
    def __init__(self,conn) -> None:
        self.CRUD = crud(conn)
    
    def get_exchange_reward(self, tujuan):
        tujuan = tujuan.lower()
        if tujuan == "dokter": return 100_000
        if tujuan == "data_ai": return 200_000
        return 0