import os
import jwt
from .crud import crud

class topup():
    def __init__(self,conn) -> None:
        self.CRUD = crud(conn)
    
    def tambah_saldo(self,user,jumlah,method):
        query = "INSERT INTO saldo (user_id, metode_pembayaran, jumlah) VALUES (%s, %s, %s)"
        params = (user, method, jumlah)
            
        return self.CRUD.query(query, params, 'simpan')