from .crud import crud
from datetime import datetime

class Authentication:
    def __init__(self,conn):
        self.CRUD = crud(conn)
        self.waktu_sekarang = datetime.now()
        
    def login(self, email: str, password: str):
        query = 'SELECT userid, namauser, email, password FROM user WHERE email = %s AND password = %s'
        return self.CRUD.query(query, (email, password), 'login')
    
    def register(self, full_name: str, email:str, password: str):
        query = "INSERT INTO user (namauser, email, password, register_date,saldo) VALUES (%s, %s, %s, %s, %s)"
        return self.CRUD.query(query,(full_name, email, password, self.waktu_sekarang,0))