import os
from dotenv import load_dotenv
from flask_wtf.csrf import CSRFProtect
from flask import Flask,send_from_directory

from models.conf import db_config
from models.auth import Authentication
from models.token import token
from models.topup import topup
from models.exchange import exchange
from models.get_cursor import get_db_connection

load_dotenv()

def create_app():
    app = Flask(__name__)
    app.secret_key = os.getenv('SECRET_KEY')
    app.config['UPLOAD_FOLDER'] = os.getenv('UPLOAD_FOLDER')
    # csrf = CSRFProtect(app)

    conn = get_db_connection(db_config)
    Token = token(conn)
    TopUp = topup(conn)
    Exchange = exchange(conn)
    auth = Authentication(conn)
    
    
    app.auth = auth
    app.token = Token
    app.Topup = TopUp
    
    from routes.user import user_bp
    from routes.auth import auth_bp
    from routes.index import index_bp
    from routes.admin import admin_bp
    from routes.api import endpoint_api_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(user_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(index_bp)
    app.register_blueprint(endpoint_api_bp)

    # Static files route
    @app.route('/node_modules/<path:filename>')
    def serve_node_modules(filename):
        node_modules_path = os.path.join(app.root_path, 'node_modules')
        return send_from_directory(node_modules_path, filename)

    return app

if __name__ == "__main__":
    app = create_app()
    app.run(host='0.0.0.0', port=8000, debug=True)