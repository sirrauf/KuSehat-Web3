from flask import Blueprint, request, current_app, jsonify
from werkzeug.utils import secure_filename
from luno_python.client import Client
import base64
import uuid
import os

endpoint_api_bp = Blueprint('endpoint_api', __name__, url_prefix='/api')
endpoint_api_bp.csrf_exempt = True

@endpoint_api_bp.route('/topup', methods=['GET', 'POST'])
def tambah_saldo():
    if request.method == "POST":
        data = request.get_json()
        user = data.get('user_id')
        metode = data.get("metode")
        jumlah = float(data.get("jumlah", 0))

        try:
            current_app.Topup.tambah_saldo(user, jumlah, metode)
            
            return jsonify({"success": True})
        except Exception as e:
            return jsonify({"success": False, "error": f"❌ Gagal mengambil alamat: {str(e)}"})
        
    return jsonify({"success": False, "error": "Error"})

@endpoint_api_bp.route('/topup', methods=['GET', 'POST'])
def exchange():
    data = request.get_json()
    user = data.get('user_id')
    if not user: return jsonify({"success": False, "message": "User tidak ditemukan"}), 404

    tujuan = data.get("tujuan")
    image_b64 = data.get('image_base64')
    image_data = base64.b64decode(image_b64)
    
    filename = f"exchange_{uuid.uuid4().hex}_{secure_filename(tujuan)}.png"
    image_path = os.path.join(current_app.config['UPLOAD_FOLDER'], filename)
    with open(image_path, "wb") as f:
        f.write(image_data)

    reward = current_app.Exchange.get_exchange_reward(tujuan)
    user.Saldo += reward
    
    return jsonify({
        "success": True, 
        "message": f"🎁 Gambar berhasil ditukar. Anda mendapat saldo IDR {reward:,}.",
        "new_saldo": user.Saldo
    })