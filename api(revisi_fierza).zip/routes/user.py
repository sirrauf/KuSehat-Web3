from flask import Blueprint,render_template,request,current_app,session,redirect
from decorator.login import login_required

user_bp = Blueprint('user', __name__, url_prefix='/user')

@user_bp.route("/overview", methods=["GET","POST"])
@login_required
def overview():
    title = "Dashboard User | KuSehat"
    return render_template(
        "dashboard/user/home.html",
        title=title,
    )

@user_bp.route("/topup", methods=["GET","POST"])
@login_required
def topup():
    title = "Documentation Api Top Up | KuSehat"
    return render_template(
        "dashboard/user/dokumentasi-api/top_up.html",
        title=title,
    )

@user_bp.route('/generate-token', methods=['GET','POST'])
@login_required
def generate_token():
    token = current_app.token.get_token(session.get('userid'))
    if request.method == "POST":
        user_id = request.form['userid']
        name = request.form['name']
        old_token = request.form['token']
        
        new_token = current_app.token.create_token(user_id)
        simpan_token = current_app.token.save_token(user_id,name,new_token,old_token)
        
        if simpan_token:
            return redirect('/user/generate-token')
            
    title = "Documentation Api Generate Token | KuSehat"
    return render_template(
        "dashboard/user/generate_token.html",
        title=title,
        token=token,
    )