from flask import Blueprint, render_template
from decorator.login import login_required

admin_bp = Blueprint('admin', __name__, url_prefix='/admin')

@admin_bp.route("/admin", methods=["GET","POST"])
@login_required
def home():
    title = "Dashboard User | KuSehat"
    return render_template(
        "dashboard/user/home.html",
        title=title,
    )